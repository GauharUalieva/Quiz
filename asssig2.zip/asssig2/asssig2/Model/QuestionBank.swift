//
//  QuestionBank.swift
//  asssig2
//
//  Created by Гаухар Уалиева on 1/28/21.
//

import Foundation
class QuestionBank{
    var list = [Question]()
    init(){
        //1
        list.append(Question(questionText: "What is the fastest land animal?", choiceA: "Tiger", choiceB: "Cheetah", choiceC: "Giraffe", choiceD: "Wolf", answer: 2))
        //2
        list.append(Question(questionText: " Which of these is the fastest fish?", choiceA: "Flying Fish", choiceB: "Shark", choiceC: "Sailfish", choiceD: "Tuna", answer: 3))
        //3
        
        list.append(Question(questionText: " What is the fastest bird?", choiceA: "Eagle", choiceB: "Stork", choiceC: "Hawk", choiceD: "Peregrine", answer: 4))
        //4
        list.append(Question(questionText: " Which of these is the shortest time span?", choiceA: "A dozen years", choiceB: "Century", choiceC: "Decade", choiceD: "Milennium", answer: 3))
        //5
        list.append(Question(questionText: " Which of these is the shortest measurement of length?", choiceA: "Gramme", choiceB: "Inch", choiceC: "Centimetre", choiceD: "Metre", answer: 3))
        //6
        list.append(Question(questionText: "Who was the shortest U.S. president?", choiceA: "Henry Harrison", choiceB: "James Madison", choiceC: "Abraham Lincoln", choiceD: "George Washington", answer: 2))
        //7
        list.append(Question(questionText: "What is the capital of Kz?", choiceA: "Astana", choiceB: "Almaty", choiceC: "Aqmola", choiceD: "Pavlodar", answer: 1))
        //8
        list.append(Question(questionText: "The capital of France?", choiceA: "Brussels", choiceB: "Paris", choiceC: "Madrid", choiceD: "Lisbon", answer: 2))
        //9
        list.append(Question(questionText: "The capital of the United States ?", choiceA: "Boston", choiceB: "New York", choiceC: "Hollywood", choiceD: "Washington", answer: 4))
        //10
        list.append(Question(questionText: "The capital of Brazil  ?", choiceA: "Santiago", choiceB: "Sao Paulo", choiceC: "Brasilia", choiceD: "Buenos Aires", answer: 3))
    }
}
